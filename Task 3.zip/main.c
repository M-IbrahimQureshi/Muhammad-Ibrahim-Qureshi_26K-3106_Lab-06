

#include <stdio.h>

int main()
{
    int Num, Num_Cube;
    printf("Press 0 to stop taking Numbers\n");
    while(Num!=0)
    {
        printf("\nEnter a Number: ");
        scanf("%d", &Num);
        Num_Cube = Num*Num*Num;
        printf("\n%d", Num_Cube);
    }
    printf("\nLoop terminated, User entered 0");
    return 0;
}