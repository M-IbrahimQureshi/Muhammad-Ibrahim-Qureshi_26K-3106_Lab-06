

#include <stdio.h>

int main()
{   
    float Prize, Total;
    int Choice, Count;
    Count = 0;
    Total = 0.0;
    char Name[30];
    printf("Enter Name of Food Item: ");
    scanf("%s", &Name);
    printf("Enter Prize of Item: ");
    scanf("%f", &Prize);
    printf("You want to Order Another Item?\n1= YES\t2 = NO\n");
    scanf("%d", &Choice);
    Total = Total + Prize;
    Count = Count + 1;
    while(Choice == 1)
    {
        printf("Enter Name of Another Item: ");
        scanf("%s", &Name);
        printf("Enter Prize of Item: ");
        scanf("%f", &Prize);
        printf("You want to Order Another Item?\n1= YES\t2 = NO\n");
        scanf("%d", &Choice);
        Total = Total + Prize;
        Count = Count + 1;
    }
    printf("0 is Pressed\tLoop Terminated\n");
    printf("Total Bill = %.2f", Total);
    printf("Number of Items ordered = %d", Count);
    
    return 0;
}