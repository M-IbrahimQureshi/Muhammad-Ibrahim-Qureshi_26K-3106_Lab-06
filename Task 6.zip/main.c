

#include <stdio.h>

int main()
{
    int Amount, Total_Saving, Count;
    Total_Saving = 0;
    Count = 0;
    printf("Enter your saving Amount: ");
    scanf("%d", &Amount);
    Total_Saving = Total_Saving + Amount;
    Count = Count + 1;
 
    while(Amount >0)
    {
        printf("Enter your saving Amount: ");
        scanf("%d", &Amount);
        Total_Saving = Total_Saving + Amount;
        Count = Count + 1;
    }
    
    printf("Total Saving = %d\n", Total_Saving);
    printf("Number of Deposits = %d\n", Count);
    return 0;
}