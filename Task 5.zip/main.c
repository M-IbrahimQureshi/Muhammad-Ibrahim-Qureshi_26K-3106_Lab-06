

#include <stdio.h>

int main()
{
    int Total_Temp = 0;
    int Temp, Count;
    Count = 0;
    for(int i=0; i<=10;i++)
    {
        printf("Enter temperature: ");
        scanf("%d", &Temp);
        Total_Temp = Total_Temp + Temp;
        if(Temp >100)
            Count = Count + 1;
    }
    
    printf("Total Temperature = %d\n", Total_Temp);    
    printf("Temperatures greater than 100 = %d\n", Count);
    
    return 0;
}