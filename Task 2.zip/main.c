

#include <stdio.h>

int main()
{
    
    for(int i = 9; i<=9&&i>=4; i--)
        printf("\n%d", i*i);        

    return 0;
}